# --The configuration file for Physics----------

# --Tensorflow Flags------------------
tf_flag = True

if tf_flag:
    import tensorflow as tf

    tf_dtype = tf.float32

