# --The configuration file for Physics----------
import tensorflow as tf


# --Tensorflow Flags------------------
tf_flag = True
tf_dtype = tf.float32

